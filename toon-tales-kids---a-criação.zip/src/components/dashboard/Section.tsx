import React from 'react';
import { BookOpen } from 'lucide-react';

interface SectionProps {
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
}

export function Section({ title, subtitle, icon, children }: SectionProps) {
  return (
    <section>
      <div className="mb-8">
        <h2 className="text-2xl sm:text-3xl font-black text-white font-brand flex items-center gap-3">
          {icon || <BookOpen className="w-7 h-7 text-sky-400" />}
          {title}
        </h2>
        {subtitle && (
          <p className="text-slate-400 mt-2 font-medium">{subtitle}</p>
        )}
      </div>
      {children}
    </section>
  );
}
