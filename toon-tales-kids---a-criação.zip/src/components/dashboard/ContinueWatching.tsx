import React from 'react';
import { Play } from 'lucide-react';
import { Episode } from '../../data/catalog';
import { motion } from 'motion/react';

interface ContinueWatchingProps {
  onSelectEpisode: (episode: Episode) => void;
}

export function ContinueWatching({ onSelectEpisode }: ContinueWatchingProps) {
  // Mock data for continue watching
  const items = [
    {
      id: 't4e10',
      title: 'A Chegada em Roma',
      progress: 68,
      timeLeft: '4 min restantes',
      image: 'https://images.unsplash.com/photo-1548625361-ec853b0a2327?q=80&w=800&auto=format&fit=crop',
      epNumber: '24'
    },
    {
      id: 't2e5',
      title: 'Davi e Golias',
      progress: 32,
      timeLeft: '8 min restantes',
      image: 'https://images.unsplash.com/photo-1464692805480-a69dfaafdb0d?q=80&w=800&auto=format&fit=crop',
      epNumber: '10'
    }
  ];

  return (
    <section>
      <h2 className="text-2xl font-black text-white font-brand mb-6 flex items-center gap-3">
        <span className="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center">
          <Play className="w-4 h-4 text-orange-500 fill-orange-500" />
        </span>
        CONTINUE OUVINDO
      </h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {items.map((item, idx) => (
          <motion.div 
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 cursor-pointer hover:border-slate-700 transition-colors"
            onClick={() => onSelectEpisode({ id: item.id } as Episode)}
          >
            <div className="aspect-video relative overflow-hidden">
              <img 
                src={item.image} 
                alt={item.title} 
                className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
              
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-2xl">
                  <Play className="w-6 h-6 text-white fill-white ml-1" />
                </div>
              </div>
            </div>
            
            <div className="p-4 relative">
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-bold text-orange-400 uppercase tracking-wider">EP. {item.epNumber}</span>
                <span className="text-xs font-medium text-slate-400">{item.timeLeft}</span>
              </div>
              <h3 className="text-lg font-bold text-white leading-tight mb-4">{item.title}</h3>
              
              {/* Progress Bar */}
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-orange-500 to-amber-400 rounded-full" 
                  style={{ width: `${item.progress}%` }} 
                />
              </div>
              <p className="text-[10px] text-slate-500 mt-2 font-bold uppercase">{item.progress}% concluído</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
