import React, { useState, useEffect } from 'react';
import { Search, Bell, User, Menu, X, PlayCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Início', active: true },
    { name: 'Histórias', active: false },
    { name: 'Temporadas', active: false },
    { name: 'Personagens', active: false },
    { name: 'Favoritos', active: false },
  ];

  return (
    <>
      <header 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-[#060B19]/90 backdrop-blur-md shadow-lg py-3' 
            : 'bg-gradient-to-b from-black/80 to-transparent py-5'
        }`}
      >
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            
            <div className="flex items-center gap-10">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-400 to-rose-500 flex items-center justify-center shadow-lg shadow-orange-500/30">
                  <PlayCircle className="w-6 h-6 text-white fill-white/20" />
                </div>
                <span className="font-brand font-bold text-xl sm:text-2xl text-white tracking-wide">
                  TOON TALES <span className="text-orange-400">KIDS</span>
                </span>
              </div>

              <nav className="hidden lg:flex items-center gap-6">
                {navLinks.map(link => (
                  <button 
                    key={link.name}
                    className={`font-medium text-sm transition-colors ${
                      link.active ? 'text-white font-bold' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    {link.name}
                  </button>
                ))}
              </nav>
            </div>

            <div className="flex items-center gap-4 sm:gap-6">
              <button className="text-slate-300 hover:text-white transition-colors">
                <Search className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
              <button className="text-slate-300 hover:text-white transition-colors relative">
                <Bell className="w-5 h-5 sm:w-6 sm:h-6" />
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-[#060B19]"></span>
              </button>
              
              <div className="hidden sm:flex items-center gap-3 pl-4 border-l border-slate-700/50">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-sky-400 to-indigo-500 border-2 border-slate-800 p-0.5 cursor-pointer">
                  <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center overflow-hidden">
                    <img src="https://api.dicebear.com/9.x/avataaars/svg?seed=Clara&backgroundColor=transparent" alt="Perfil" className="w-full h-full object-cover" />
                  </div>
                </div>
                <span className="text-sm font-bold text-white hidden md:block">Clara</span>
              </div>

              <button 
                className="lg:hidden text-slate-300 hover:text-white"
                onClick={() => setIsMobileMenuOpen(true)}
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Mobile Navigation Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[60] bg-[#060B19] flex flex-col"
          >
            <div className="flex items-center justify-between p-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-400 to-rose-500 flex items-center justify-center">
                  <PlayCircle className="w-5 h-5 text-white" />
                </div>
                <span className="font-brand font-bold text-xl text-white">TOON TALES KIDS</span>
              </div>
              <button 
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-2 bg-slate-800 rounded-full text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto py-8 px-6 flex flex-col gap-6">
              {navLinks.map(link => (
                <button 
                  key={link.name}
                  className={`text-2xl font-bold text-left ${
                    link.active ? 'text-orange-400' : 'text-white'
                  }`}
                >
                  {link.name}
                </button>
              ))}
              <div className="h-px bg-slate-800 my-4" />
              <button className="text-2xl font-bold text-left text-white flex items-center gap-3">
                <User className="w-6 h-6" /> Meu Perfil
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
