import React from 'react';
import { Navbar } from './Navbar';
import { Hero } from './Hero';
import { ContinueWatching } from './ContinueWatching';
import { Section } from './Section';
import { EpisodeCard } from './EpisodeCard';
import { SeasonSection } from './SeasonSection';
import { CharacterSection } from './CharacterSection';
import { Footer } from './Footer';
import { BIBLE_SEASONS, Episode } from '../../data/catalog';
import { motion } from 'motion/react';

interface DashboardProps {
  onSelectEpisode: (episode: Episode) => void;
}

export function Dashboard({ onSelectEpisode }: DashboardProps) {
  // Get some featured episodes for "A Bíblia em Áudio" section
  const allEpisodes = BIBLE_SEASONS.flatMap(s => s.episodes);
  const featuredEpisodes = allEpisodes.filter(e => e.isAvailable).slice(0, 8);
  
  // Hero episode (e.g. Paul in Rome or Creation)
  const heroEpisode = allEpisodes.find(e => e.id === 't4e10') || allEpisodes[0];

  return (
    <div className="min-h-screen bg-[#060B19] text-slate-100 font-sans pb-20 sm:pb-0 overflow-x-hidden">
      <Navbar />
      
      <main className="w-full">
        <Hero 
          episode={heroEpisode} 
          onPlay={() => onSelectEpisode(heroEpisode)} 
        />
        
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
          <ContinueWatching onSelectEpisode={onSelectEpisode} />
          
          <Section title="A Bíblia em Áudio" subtitle="Grandes aventuras para você descobrir">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 sm:gap-6">
              {featuredEpisodes.map(ep => (
                <EpisodeCard key={ep.id} episode={ep} onPlay={() => onSelectEpisode(ep)} />
              ))}
            </div>
          </Section>
          
          <SeasonSection />
          
          <Section title="Talvez Você Goste" subtitle="Porque você ouviu Davi e Golias" icon={<span className="text-3xl">⭐</span>}>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 sm:gap-6">
              {allEpisodes.filter(e => e.isAvailable).slice(4, 10).map(ep => (
                <EpisodeCard key={ep.id} episode={ep} onPlay={() => onSelectEpisode(ep)} />
              ))}
            </div>
          </Section>

          <CharacterSection />
        </div>
      </main>

      <Footer />
    </div>
  );
}
