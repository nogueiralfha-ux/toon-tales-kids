import React from 'react';
import { Users } from 'lucide-react';
import { motion } from 'motion/react';

export function CharacterSection() {
  const characters = [
    {
      id: 1,
      name: 'DAVI',
      desc: 'O jovem pastor que enfrentou um gigante.',
      color: 'from-orange-500 to-rose-500'
    },
    {
      id: 2,
      name: 'NOÉ',
      desc: 'Construiu a grande arca da promessa.',
      color: 'from-sky-500 to-indigo-500'
    },
    {
      id: 3,
      name: 'ESTER',
      desc: 'A rainha corajosa que salvou seu povo.',
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 4,
      name: 'DANIEL',
      desc: 'Fé inabalável na cova dos leões.',
      color: 'from-emerald-500 to-teal-500'
    }
  ];

  return (
    <section>
      <div className="mb-8">
        <h2 className="text-2xl sm:text-3xl font-black text-white font-brand flex items-center gap-3">
          <Users className="w-7 h-7 text-emerald-400" />
          CONHEÇA OS PERSONAGENS
        </h2>
        <p className="text-slate-400 mt-2 font-medium">Os heróis que fazem parte dessas aventuras</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {characters.map((char, idx) => (
          <motion.div
            key={char.id}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className="group relative rounded-3xl p-6 overflow-hidden cursor-pointer bg-slate-900 border border-slate-800 hover:border-slate-600 transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl flex flex-col items-center text-center"
          >
            <div className={`absolute top-0 left-0 w-full h-32 bg-gradient-to-b ${char.color} opacity-20 group-hover:opacity-40 transition-opacity`} />
            
            <div className="w-24 h-24 rounded-full border-4 border-slate-800 bg-slate-800 relative z-10 mb-4 overflow-hidden group-hover:scale-110 transition-transform duration-300">
              <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=${char.name}&backgroundColor=transparent`} alt={char.name} className="w-full h-full object-cover" />
            </div>
            
            <h3 className="text-xl font-black text-white font-brand mb-2 relative z-10">{char.name}</h3>
            <p className="text-sm text-slate-400 relative z-10 mb-6 flex-1">{char.desc}</p>
            
            <button className="relative z-10 px-6 py-2 rounded-full bg-slate-800 text-white text-xs font-bold hover:bg-slate-700 transition-colors uppercase tracking-widest border border-slate-700">
              Conhecer
            </button>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
