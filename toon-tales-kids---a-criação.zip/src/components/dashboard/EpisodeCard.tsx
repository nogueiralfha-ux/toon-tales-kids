import React from 'react';
import { Play } from 'lucide-react';
import { Episode } from '../../data/catalog';
import { motion } from 'motion/react';

interface EpisodeCardProps {
  key?: React.Key;
  episode: Episode;
  onPlay: () => void;
}

export function EpisodeCard({ episode, onPlay }: EpisodeCardProps) {
  // Try to generate a semi-random but consistent image for the mock 3D look
  // In production this would come from episode.coverUrl
  const seed = episode.id;
  const imageUrl = `https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?q=80&w=600&auto=format&fit=crop`;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4 }}
      className="group relative w-full aspect-[3/4] rounded-2xl sm:rounded-3xl overflow-hidden cursor-pointer bg-slate-900 border border-slate-800 transition-all duration-250 hover:shadow-2xl hover:shadow-sky-900/40 hover:-translate-y-2 hover:border-slate-600"
      onClick={onPlay}
    >
      {/* Background Image */}
      <img 
        src={imageUrl} 
        alt={episode.title}
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
      />
      
      {/* Gradients for text legibility */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
      
      {/* Content */}
      <div className="absolute inset-0 p-4 sm:p-5 flex flex-col justify-end">
        
        {/* Hover info (Slides up) */}
        <div className="transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 mb-3 flex flex-col gap-2">
          <div className="w-12 h-12 rounded-full bg-orange-500 flex items-center justify-center shadow-lg shadow-orange-500/40 mb-2">
            <Play className="w-5 h-5 text-white fill-white ml-1" />
          </div>
          <p className="text-xs text-slate-300 line-clamp-2">
            {episode.description}
          </p>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[10px] sm:text-xs font-black text-sky-400 uppercase tracking-wider">
              EP. {episode.id.replace('t', '').replace('e', '.')}
            </span>
            <span className="text-[10px] text-slate-400 font-bold uppercase">
              12 MIN
            </span>
          </div>
          <h3 className="text-sm sm:text-base font-black text-white font-brand leading-tight group-hover:text-sky-300 transition-colors">
            {episode.title}
          </h3>
        </div>
      </div>
    </motion.div>
  );
}
