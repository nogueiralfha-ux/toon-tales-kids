import React from 'react';
import { Play, Plus } from 'lucide-react';
import { motion } from 'motion/react';
import { Episode } from '../../data/catalog';

interface HeroProps {
  episode: Episode;
  onPlay: () => void;
}

export function Hero({ episode, onPlay }: HeroProps) {
  // We'll use a placeholder cinematic background, or we could use the episode's cover
  // Let's use a rich cinematic gradient with an implied 3D landscape background
  
  return (
    <div className="relative w-full h-[70vh] sm:h-[80vh] min-h-[500px] flex items-end pb-12 sm:pb-24">
      {/* Background Image & Overlays */}
      <div className="absolute inset-0 overflow-hidden bg-slate-900">
        <img 
          src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=2560&auto=format&fit=crop" 
          alt="Hero Background" 
          className="w-full h-full object-cover object-top opacity-60 mix-blend-overlay"
        />
        {/* Dynamic lighting effects to make it feel 3D/Cinematic */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#060B19] via-[#060B19]/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#060B19] via-[#060B19]/80 to-transparent w-full md:w-3/4" />
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-sky-500/10 blur-[120px] rounded-full" />
      </div>

      <div className="relative z-10 max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="flex items-center gap-3 mb-4">
              <span className="px-3 py-1 bg-rose-500/20 text-rose-300 text-xs font-black uppercase tracking-wider rounded-md border border-rose-500/30">
                Lançamento
              </span>
              <span className="text-slate-300 text-sm font-bold uppercase tracking-widest flex items-center gap-2">
                A BÍBLIA EM ÁUDIO
              </span>
            </div>

            <h1 className="text-4xl sm:text-6xl md:text-7xl font-black text-white font-brand leading-tight mb-4 drop-shadow-2xl">
              Aventure-se por <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-300 to-amber-500">
                grandes histórias
              </span>
            </h1>
            
            <p className="text-base sm:text-lg text-slate-300 font-medium mb-8 max-w-xl leading-relaxed">
              Ouça histórias emocionantes, conheça personagens inesquecíveis e descubra lições que podem transformar sua vida.
            </p>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <button 
                onClick={onPlay}
                className="group relative flex items-center justify-center gap-3 bg-white text-slate-900 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-slate-100 transition-all hover:scale-105 active:scale-95 shadow-xl shadow-white/10 w-full sm:w-auto"
              >
                <div className="w-8 h-8 rounded-full bg-slate-900/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Play className="w-4 h-4 fill-current" />
                </div>
                OUVIR AGORA
              </button>
              
              <button className="flex items-center justify-center gap-3 bg-slate-800/80 backdrop-blur-md text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-slate-700 transition-all border border-slate-700 hover:scale-105 active:scale-95 w-full sm:w-auto">
                <Plus className="w-6 h-6" />
                MINHA LISTA
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
