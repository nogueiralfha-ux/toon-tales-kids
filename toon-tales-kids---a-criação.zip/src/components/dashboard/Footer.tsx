import React from 'react';
import { PlayCircle, ShieldCheck } from 'lucide-react';

export function Footer() {
  return (
    <footer className="mt-24 border-t border-slate-800 bg-[#060B19] py-12">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-400 to-rose-500 flex items-center justify-center">
              <PlayCircle className="w-5 h-5 text-white" />
            </div>
            <span className="font-brand font-bold text-xl text-white">
              TOON TALES <span className="text-orange-400">KIDS</span>
            </span>
          </div>
          
          <div className="flex gap-6 text-sm font-medium text-slate-400">
            <a href="#" className="hover:text-white transition-colors">Sobre</a>
            <a href="#" className="hover:text-white transition-colors">Privacidade</a>
            <a href="#" className="hover:text-white transition-colors">Termos</a>
            <a href="#" className="flex items-center gap-1 hover:text-white transition-colors">
              <ShieldCheck className="w-4 h-4" /> Área dos Pais
            </a>
          </div>
        </div>
        
        <div className="mt-8 text-center text-xs text-slate-600">
          <p>Histórias que ensinam, aventuras que transformam!</p>
          <p className="mt-2">&copy; {new Date().getFullYear()} Toon Tales Cinematic Universe. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
