import React from 'react';
import { Film } from 'lucide-react';
import { motion } from 'motion/react';

export function SeasonSection() {
  const seasons = [
    {
      id: 1,
      title: 'TEMPORADA 1',
      subtitle: 'O COMEÇO',
      theme: 'bg-emerald-900 border-emerald-700 hover:shadow-emerald-900/40',
      image: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?q=80&w=800&auto=format&fit=crop'
    },
    {
      id: 2,
      title: 'TEMPORADA 2',
      subtitle: 'GRANDES AVENTURAS',
      theme: 'bg-amber-900 border-amber-700 hover:shadow-amber-900/40',
      image: 'https://images.unsplash.com/photo-1544885822-2619084803d2?q=80&w=800&auto=format&fit=crop'
    },
    {
      id: 3,
      title: 'TEMPORADA 3',
      subtitle: 'JESUS',
      theme: 'bg-sky-900 border-sky-700 hover:shadow-sky-900/40',
      image: 'https://images.unsplash.com/photo-1490730141103-6cac27aaab94?q=80&w=800&auto=format&fit=crop'
    },
    {
      id: 4,
      title: 'TEMPORADA 4',
      subtitle: 'IGREJA E APÓSTOLOS',
      theme: 'bg-rose-900 border-rose-700 hover:shadow-rose-900/40',
      image: 'https://images.unsplash.com/photo-1522062635955-40fa40108871?q=80&w=800&auto=format&fit=crop'
    }
  ];

  return (
    <section>
      <div className="mb-8 flex items-center justify-between">
        <h2 className="text-2xl sm:text-3xl font-black text-white font-brand flex items-center gap-3">
          <Film className="w-7 h-7 text-rose-400" />
          EXPLORE AS TEMPORADAS
        </h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {seasons.map((season, idx) => (
          <motion.div
            key={season.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1 }}
            className={`group relative aspect-[16/10] sm:aspect-square rounded-3xl overflow-hidden cursor-pointer border ${season.theme} transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl`}
          >
            <img 
              src={season.image} 
              alt={season.subtitle}
              className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-overlay group-hover:opacity-80 group-hover:scale-110 transition-all duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
            
            <div className="absolute inset-0 p-6 flex flex-col justify-end">
              <span className="text-xs font-black text-white/70 uppercase tracking-widest mb-1">
                {season.title}
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-white font-brand leading-tight group-hover:text-white transition-colors">
                {season.subtitle}
              </h3>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Season 5 Highlight */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mt-6 relative w-full rounded-3xl overflow-hidden border border-amber-500/30 cursor-pointer group hover:border-amber-400/60 transition-all duration-300 shadow-xl shadow-amber-900/20"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-amber-950 via-slate-900 to-indigo-950" />
        
        <div className="relative p-8 sm:p-12 flex flex-col sm:flex-row items-center justify-between gap-8 z-10">
          <div className="flex-1">
            <span className="inline-block px-4 py-1.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-black uppercase tracking-widest mb-4">
              Lançamento Especial
            </span>
            <h2 className="text-3xl sm:text-5xl font-black text-white font-brand mb-3">
              🛡️ HERÓIS DA FÉ
            </h2>
            <p className="text-lg text-amber-200/90 font-medium">
              Pessoas comuns. Grandes desafios. Uma fé extraordinária.
            </p>
          </div>
          
          <div className="flex -space-x-4">
            {/* Mock avatars for characters */}
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-4 border-slate-900 bg-slate-800 overflow-hidden shadow-lg transform transition-transform group-hover:scale-110" style={{ transitionDelay: `${i * 50}ms` }}>
                <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=Hero${i}&backgroundColor=transparent`} alt="Hero" className="w-full h-full object-cover" />
              </div>
            ))}
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-4 border-slate-900 bg-amber-500 flex items-center justify-center text-white font-black text-xl shadow-lg z-10">
              +6
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
